import { ActionTree } from 'vuex'
import { RootState } from '../state'
import { ExampleState } from './state'

export const actions: ActionTree<ExampleState, RootState> = {}
