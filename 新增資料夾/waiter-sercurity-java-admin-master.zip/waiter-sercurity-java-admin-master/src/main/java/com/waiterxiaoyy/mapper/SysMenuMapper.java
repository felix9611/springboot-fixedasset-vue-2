package com.waiterxiaoyy.mapper;

import com.waiterxiaoyy.entity.SysMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author WaiterXiaoYY
 * @since 2022-01-13
 */
public interface SysMenuMapper extends BaseMapper<SysMenu> {

}
