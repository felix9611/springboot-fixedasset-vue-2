<template>
  <v-app>
    <Widget />
    <div></div>
  </v-app>
</template>

<script lang="ts">
import { Component, Mixins } from 'vue-property-decorator'
import ComponentMixin from '@/components/mixins/ComponentMixin'
import Widget from '@/Widget.vue'

@Component({
  components: {
    Widget
  }
})
export default class App extends Mixins(ComponentMixin) {

}
</script>
<style lang="scss" scoped>
</style>
<style lang="scss">
</style>
