package com.waiterxiaoyy.mapper;

import com.waiterxiaoyy.entity.SysRoleMenu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author WaiterXiaoYY
 * @since 2022-01-13
 */
public interface SysRoleMenuMapper extends BaseMapper<SysRoleMenu> {

}
