package com.waiterxiaoyy.common.lang;

public class Const {

	public final static String CAPTCHA_KEY = "captcha";

	// 状态
	public final static Integer STATUS_ON = 0;
	public final static Integer STATUS_OFF = 1;

	// 初始密码
	public static final String DEFULT_PASSWORD = "888888";

	// 默认头像
	public static final String DEFULT_AVATAR = "https://blog20211013.oss-cn-shenzhen.aliyuncs.com/%E6%9C%BA%E5%99%A8%E4%BA%BA%20(1).png?versionId=CAEQMxiBgIC5geHI8xciIGMxYjNlYWRhNTBmMzQxZTlhM2VhOTAxMTI3ODI1ZjM4";
}
