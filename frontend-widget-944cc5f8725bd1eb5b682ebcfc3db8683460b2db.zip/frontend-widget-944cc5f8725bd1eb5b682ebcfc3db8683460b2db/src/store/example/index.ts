import { Module } from 'vuex'
import { RootState } from '../state'
import { state, ExampleState } from './state'
import { mutations } from './mutations'
import { actions } from './actions'

export const example: Module<ExampleState, RootState> = {
  namespaced: true,
  state,
  mutations,
  actions,
}
