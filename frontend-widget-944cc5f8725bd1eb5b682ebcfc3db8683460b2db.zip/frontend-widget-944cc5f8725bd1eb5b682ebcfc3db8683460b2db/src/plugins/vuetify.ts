import Vue from 'vue'
import Vuetify from 'vuetify'
import 'vuetify/dist/vuetify.min.css'

Vue.use(Vuetify);

export default new Vuetify({
  theme: {
    disable: true
  },
  icons: {
    iconfont: 'md'
  },
  breakpoint: {
    thresholds: {
      xs: 600,
      sm: 960,
      md: 1366,
      lg: 1920,
    }
  }
});
