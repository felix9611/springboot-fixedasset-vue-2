<template>
    <div>用户主页</div>
</template>

<script>
    export default {
        name: "UserIndex"
    }
</script>

<style scoped>

</style>