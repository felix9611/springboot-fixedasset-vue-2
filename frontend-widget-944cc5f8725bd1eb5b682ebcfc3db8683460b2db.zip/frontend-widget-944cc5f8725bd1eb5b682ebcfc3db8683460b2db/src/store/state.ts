import { ExampleState } from './example/state'

export interface RootState {
  example: ExampleState
}
