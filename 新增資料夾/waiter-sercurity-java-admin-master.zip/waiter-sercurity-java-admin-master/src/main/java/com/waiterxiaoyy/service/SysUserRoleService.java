package com.waiterxiaoyy.service;

import com.waiterxiaoyy.entity.SysUserRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WaiterXiaoYY
 * @since 2022-01-13
 */
public interface SysUserRoleService extends IService<SysUserRole> {

}
