<template>
  <v-app>
    <p>Here is inside the widget</p>
    <link
      v-for="cssFile in cssFiles"
      :id="`InnerStyleSheet-${cssFile}`"
      :key="`Inner-${cssFile}`"
      :href="cssFile"
      rel="stylesheet"
    >
  </v-app>
</template>
<script lang="ts">
import Vue from 'vue'
import vuetify from './plugins/vuetify'
import { Component, Mixins } from 'vue-property-decorator'
import ComponentMixin from '@/components/mixins/ComponentMixin'
import store from '@/store'

const production = process.env.NODE_ENV === 'production'
Vue.config.silent = production
Vue.config.devtools = !production
Vue.config.productionTip = !production
Vue.config.performance = !production
Vue.config.async = true

@Component({
  store,
  vuetify,
})
export default class Widget extends Mixins(ComponentMixin) {
  get domain(): string {
    return `https://localhost:8080`
  }

  get cssFiles(): string[] {
    return [
      `${this.domain}/cdn/css/vuetify.css`,
      `${this.domain}/cdn/css/roboto.css`,
      `${this.domain}/cdn/css/material-icon.css`,
      `${this.domain}/cdn/css/fontawesome.css`,
    ]
  }
}
</script>
<style lang="scss" scoped>
.widget {
}
</style>
<style lang="scss">
.widget {
}
</style>
