package com.waiterxiaoyy.service;

import com.waiterxiaoyy.entity.SysRoleMenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author WaiterXiaoYY
 * @since 2022-01-13
 */
public interface SysRoleMenuService extends IService<SysRoleMenu> {

}
