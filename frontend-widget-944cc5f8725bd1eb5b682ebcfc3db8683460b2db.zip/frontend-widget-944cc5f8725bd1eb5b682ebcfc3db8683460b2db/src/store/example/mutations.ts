import { MutationTree } from 'vuex'
import { ExampleState } from './state'

export const mutations: MutationTree<ExampleState> = {}
