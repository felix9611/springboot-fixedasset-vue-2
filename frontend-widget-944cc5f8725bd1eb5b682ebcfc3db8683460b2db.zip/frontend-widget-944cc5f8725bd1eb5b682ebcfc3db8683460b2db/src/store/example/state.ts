export interface ExampleState {}

export const state: ExampleState = {}
